# Data Specification

Take 'teapot' for example.

> 32 # total number of patches
> 
> #Below are the point indexes of the 32 patches. Each patch has 16 control points.
> 
> 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16
> 
> 4,17,18,19,8,20,21,22,12,23,24,25,16,26,27,28
> 
> 19,29,30,31,22,32,33,34,25,35,36,37,28,38,39,40
> 
> ......
> 
> 270,270,270,270,300,305,306,279,297,303,304,275,294,301,302,271
> 
> 306  # total number of vertices
> 
> #Below are the coordinates of the 306 vertices
> 
> 1.4,0.0,2.4
> 
> 1.4,-0.784,2.4
> 
> ......
> 
> 1.425,-0.798,0.0


